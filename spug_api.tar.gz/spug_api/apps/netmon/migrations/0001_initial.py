from django.db import migrations, models
import django.db.models.deletion
from libs import human_datetime


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('account', '0001_initial'),
        ('host', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='NetGroup',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=50)),
                ('parent_id', models.IntegerField(default=0)),
                ('sort_id', models.IntegerField(default=0)),
            ],
            options={
                'db_table': 'netmon_groups',
                'ordering': ('-sort_id', 'id'),
            },
        ),
        migrations.CreateModel(
            name='Device',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=100)),
                ('ip', models.CharField(db_index=True, max_length=50)),
                ('category', models.CharField(choices=[('server', '服务�?), ('switch', '交换�?), ('router', '路由�?), ('firewall', '防火�?), ('load_balancer', '负载均衡'), ('storage', '存储设备'), ('database', '数据�?), ('middleware', '中间�?), ('application', '业务应用'), ('other', '其他')], default='server', max_length=20)),
                ('vendor', models.CharField(blank=True, max_length=50, null=True)),
                ('model_name', models.CharField(blank=True, max_length=50, null=True)),
                ('location', models.CharField(blank=True, max_length=100, null=True)),
                ('monitor_type', models.CharField(choices=[('ping', 'Ping探测'), ('snmp', 'SNMP采集'), ('agent', 'Agent(SSH)采集'), ('http', 'HTTP探测')], default='ping', max_length=10)),
                ('snmp_version', models.CharField(default='2c', max_length=5)),
                ('snmp_community', models.CharField(default='public', max_length=50)),
                ('snmp_port', models.IntegerField(default=161)),
                ('rate', models.IntegerField(default=60, help_text='采集周期(�?')),
                ('status', models.CharField(choices=[('unknown', '未知'), ('online', '正常'), ('warning', '告警'), ('critical', '严重'), ('offline', '离线')], default='unknown', max_length=10)),
                ('last_value', models.TextField(blank=True, help_text='最近一次采集到的指标快�?JSON)', null=True)),
                ('latest_check_at', models.CharField(max_length=20, null=True)),
                ('is_active', models.BooleanField(default=True)),
                ('desc', models.CharField(blank=True, max_length=255, null=True)),
                ('created_at', models.CharField(default=human_datetime, max_length=20)),
                ('group', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='devices', to='netmon.NetGroup')),
                ('host', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='+', to='host.Host')),
                ('created_by', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='+', to='account.User')),
            ],
            options={
                'db_table': 'netmon_devices',
                'ordering': ('-id',),
            },
        ),
        migrations.CreateModel(
            name='Link',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('link_type', models.CharField(choices=[('physical', '物理链路'), ('logical', '逻辑链路')], default='physical', max_length=10)),
                ('bandwidth_mbps', models.IntegerField(blank=True, null=True)),
                ('desc', models.CharField(blank=True, max_length=255, null=True)),
                ('source', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='links_out', to='netmon.Device')),
                ('target', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='links_in', to='netmon.Device')),
            ],
            options={
                'db_table': 'netmon_links',
            },
        ),
        migrations.CreateModel(
            name='MetricRecord',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('metric_key', models.CharField(choices=[('rtt', '时延(ms)'), ('loss', '丢包�?%)'), ('cpu', 'CPU使用�?%)'), ('memory', '内存使用�?%)'), ('disk', '磁盘使用�?%)'), ('net_in', '入流�?Kbps)'), ('net_out', '出流�?Kbps)')], max_length=20)),
                ('value', models.FloatField()),
                ('unit', models.CharField(blank=True, max_length=10, null=True)),
                ('collected_at', models.DateTimeField(auto_now_add=True, db_index=True)),
                ('device', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='metrics', to='netmon.Device')),
            ],
            options={
                'db_table': 'netmon_metric_records',
                'ordering': ('-collected_at',),
            },
        ),
        migrations.CreateModel(
            name='AlertRule',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=50)),
                ('metric_key', models.CharField(max_length=20)),
                ('operator', models.CharField(choices=[('>', '大于'), ('>=', '大于等于'), ('<', '小于'), ('<=', '小于等于'), ('==', '等于')], max_length=2)),
                ('threshold', models.FloatField()),
                ('consecutive_times', models.IntegerField(default=1)),
                ('level', models.CharField(choices=[('info', '提示'), ('warning', '告警'), ('critical', '严重')], default='warning', max_length=10)),
                ('notify_grp', models.CharField(default='[]', max_length=255)),
                ('notify_mode', models.CharField(default='[]', max_length=255)),
                ('is_active', models.BooleanField(default=True)),
                ('created_at', models.CharField(default=libs.human_datetime, max_length=20)),
                ('device', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name='alert_rules', to='netmon.Device')),
                ('group', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='netmon.NetGroup')),
                ('created_by', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='+', to='account.User')),
            ],
            options={
                'db_table': 'netmon_alert_rules',
                'ordering': ('-id',),
            },
        ),
        migrations.CreateModel(
            name='AnomalyEvent',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('metric_key', models.CharField(max_length=20)),
                ('value', models.FloatField()),
                ('baseline', models.FloatField(null=True)),
                ('deviation', models.FloatField(null=True)),
                ('method', models.CharField(choices=[('threshold', '静态阈�?), ('3sigma', '3-sigma动态基�?), ('ewma', 'EWMA平滑基线')], default='threshold', max_length=10)),
                ('level', models.CharField(choices=[('info', '提示'), ('warning', '告警'), ('critical', '严重')], default='warning', max_length=10)),
                ('message', models.CharField(max_length=255)),
                ('status', models.CharField(choices=[('open', '未处�?), ('acknowledged', '已确�?), ('resolved', '已恢�?)], default='open', max_length=15)),
                ('created_at', models.CharField(default=libs.human_datetime, max_length=20)),
                ('resolved_at', models.CharField(max_length=20, null=True)),
                ('device', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='anomalies', to='netmon.Device')),
            ],
            options={
                'db_table': 'netmon_anomaly_events',
                'ordering': ('-id',),
            },
        ),
        migrations.CreateModel(
            name='Report',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=100)),
                ('report_type', models.CharField(choices=[('daily', '日报'), ('weekly', '周报'), ('monthly', '月报'), ('manual', '手动/自定�?)], default='daily', max_length=10)),
                ('recipients', models.CharField(default='[]', help_text='通知联系组id列表(JSON)', max_length=255)),
                ('is_active', models.BooleanField(default=True)),
                ('last_generated_at', models.CharField(max_length=20, null=True)),
                ('created_at', models.CharField(default=libs.human_datetime, max_length=20)),
                ('group', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, help_text='为空表示统计全部资源', to='netmon.NetGroup')),
                ('created_by', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='+', to='account.User')),
            ],
            options={
                'db_table': 'netmon_reports',
                'ordering': ('-id',),
            },
        ),
        migrations.CreateModel(
            name='ReportRecord',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('period_start', models.CharField(max_length=20)),
                ('period_end', models.CharField(max_length=20)),
                ('file_path', models.CharField(max_length=255)),
                ('summary', models.TextField(default='{}')),
                ('created_at', models.CharField(default=libs.human_datetime, max_length=20)),
                ('report', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='records', to='netmon.Report')),
            ],
            options={
                'db_table': 'netmon_report_records',
                'ordering': ('-id',),
            },
        ),
        migrations.AddIndex(
            model_name='metricrecord',
            index=models.Index(fields=['device', 'metric_key', 'collected_at'], name='netmon_metric_device_key_collected_idx'),
        ),
    ]
